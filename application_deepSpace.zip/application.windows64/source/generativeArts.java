import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.lang.*; 
import java.lang.reflect.*; 
import processing.core.*; 
import TUIO.*; 
import java.util.*; 
import processing.sound.*; 

import TUIO.*; 
import com.illposed.osc.*; 
import com.illposed.osc.utility.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class generativeArts extends PApplet {

SceneManager sm;
DeepSpaceManager dsm;

// Load a soundfile from the /data folder of the sketch and play it back
SoundFile file ;

public void settings() {
  dsm = new DeepSpaceManager();
  // size has to be inited in settings when using OOP
  //size(dsm.windowWidth, dsm.windowHeight, FX2D ); 
  fullScreen(P2D, SPAN);

  smooth();
  file = new SoundFile(this, "music.mp3");
  file.play();
}

public void setup() {
  frameRate(dsm.FrameRate);
  dsm.doSetup();


  sm = new SceneManager(this);
}

public void draw() {
  // draw upper / lower area of deep space and tracking helpers
  sm.doDraw();
  // dsm.drawDSMHelpers();
}


public void keyPressed() {
  sm.handleKeyPressed();
  dsm.handleKeyPressed();
}

public void mouseClicked() {
  sm.handleMouseClicked();
}

public void mouseDragged() {
  sm.handleMouseDragged();
}

public void mousePressed() {
  sm.handleMousePressed();
}

public void mouseReleased() {
  sm.handleMouseReleased();
}

class DeepSpaceManager {
  float cursor_size = 25;
  PFont font;

  int shrink = 1;
  int windowWidth = 3030 / shrink; // for real Deep Space this should be 3030
  int windowHeight = 3712 / shrink; // for real Deep Space this should be 3712
  int wallHeight = 1914 / shrink; // for real Deep Space this should be 1914 
  int floorHeight = 1798 / shrink; // for real Deep Space this should be 1798 
  int FrameRate = 30;

  boolean showTrack = true;
  boolean showPath = false;
  boolean showFeet = false;
  boolean helpersDrawn = false;

  public void doSetup() {
    noStroke();
    fill(255);

    font = createFont("Arial", 18);
    textFont(font, 12);
    textAlign(CENTER, CENTER);

    initPlayerTracking();
  }

  public void drawDSMHelpers() {
    if (!helpersDrawn) {
      // clear background with black
      background(0);

      // set upper half of window (=wall projection) bluish
      noStroke();
      fill(21, 8, 50);
      rect(0, 0, windowWidth, wallHeight);
      helpersDrawn = true;
    }

    fill(255);
    text((int)FrameRate + " FPS", width / 2, 10);
    text("Width: " + this.windowWidth, width / 2, 30);
    text("Wall height: " + this.wallHeight, width / 2, 50);

    drawPlayerTracking();
  }

  public void handleKeyPressed()
  {
    println("handle key:" + key);
    switch(Character.toLowerCase(key)) {
    case 'p':
      showPath = !showPath;
      break;
    case 't':
      showTrack = !showTrack;
      break;
    case 'f':
      showFeet = !showFeet;
      break;
    }
  }
}

// Version 3.1
// this class replaces former TUIOHelper in this new and enhanced implementation
// do not change anything in here unless you are really sure of what you are doing







// reference: https://github.com/processing/processing/wiki/Library-Basics
public class PharusClient extends PApplet 
{
  // internal stuff only
  PApplet parent;
  TuioProcessing tuioProcessing;
  int nextUniqueID = 0;
  Method playerAddEventMethod;
  Method playerRemoveEventMethod;
  int wallHeight = 0;

  boolean doDebug = false;  
  int maxAge = 50; // age is measured in update cycles, with 25 fps this is 2 seconds
  float jumpDistanceMaxTolerance = 0.05f; // max distance allowed when jumping between last known position and potential landing position, unit is in pixels relative to window width
  HashMap<Long, Player> players = new HashMap<Long, Player>();

  PharusClient(PApplet _parent, int _wallHeight) 
  {
    this.parent = _parent;
    this.wallHeight = _wallHeight;
    // this is a bit of a hack but need for TuioProcessing to work properly
    width = parent.width;
    height = parent.height;
    tuioProcessing = new TuioProcessing(this); 

    parent.registerMethod("dispose", this);
    parent.registerMethod("pre", this); 

    // check to see if the host applet implements event functions
    try 
    {
      playerAddEventMethod = parent.getClass().getMethod("pharusPlayerAdded", new Class[] { Player.class });
    } 
    catch (Exception e) 
    {
      // no such method, or an error..
      println("Function pharusPlayerAdded() not found, Player add events disabled.");
    }
    try 
    {
      playerRemoveEventMethod = parent.getClass().getMethod("pharusPlayerRemoved", new Class[] { Player.class });
    } 
    catch (Exception e) 
    {
      // no such method, or an error..
      println("Function pharusPlayerRemoved() not found, Player remove events disabled.");
    }    
  }
  
  // age is measured in update cycles, with 25 fps this is 2 seconds
  public void setMaxAge(int age)
  {
    maxAge = age;
  }

  // max distance allowed when jumping between last known position and potential landing position, unit is in pixels relative to window width
  public void setjumpDistanceMaxTolerance(float relDist)
  {
    jumpDistanceMaxTolerance = relDist;
  }

  public void firePlayerAddEvent(Player player) 
  {
    if (playerAddEventMethod != null) 
    {
      try 
      {
        playerAddEventMethod.invoke(parent, new Object[] { player });
      } 
      catch (Exception e) 
      {
        System.err.println("Disabling event for " + playerAddEventMethod.getName() + " because of an error.");
        e.printStackTrace();
        playerAddEventMethod = null;
      }
    }
  }
  
  public void firePlayerRemoveEvent(Player player) 
  {
    if (playerRemoveEventMethod != null) 
    {
      try 
      {
        playerRemoveEventMethod.invoke(parent, new Object[] { player });
      } 
      catch (Exception e) 
      {
        System.err.println("Disabling event for " + playerRemoveEventMethod.getName() + " because of an error.");
        e.printStackTrace();
        playerRemoveEventMethod = null;
      }
    }
  }

  public void dispose() 
  {
    // Anything in here will be called automatically when the parent sketch shuts down.
    players.clear();
    tuioProcessing.dispose();
  }

  public void pre() 
  {
    // Method that's called just after beginDraw(), meaning that it can affect drawing.

    int m = millis();

    // Increase age of all players, remove those too old
    Iterator<HashMap.Entry<Long, Player>> iter = players.entrySet().iterator();
    while (iter.hasNext()) 
    {
      HashMap.Entry<Long, Player> playersEntry = iter.next();
      Player p = (Player)playersEntry.getValue();
      p.feet.clear();  
      p.age++;
      // remove if too old
      if (p.age > maxAge)
      {
          firePlayerRemoveEvent(p);
          iter.remove();
      }
    }
    
    // Update known players with available tuio data
    ArrayList<TuioCursor> tcl = tuioProcessing.getTuioCursorList();
    int i = 0;
    while (i < tcl.size())
    {
      TuioCursor tc = tcl.get(i);
      Player p = players.get(tc.getSessionID());
      if (p != null)
      {
        // update player
        p.age = 0;
        p.x = tc.getScreenX(width);
        p.y = tc.getScreenY(height - wallHeight) + wallHeight;
        tcl.remove(i);
      }
      else
      {
        i++;
      }
    }

    // check if there are new players left and handle them accordingly 
    if (tcl.size() > 0)
    {
      for (TuioCursor tc : tcl)
      {
        boolean found = false;
        // check if this was a previously known player with different id (TUIO id swap case due to jumping e.g.)
        for (HashMap.Entry<Long, Player> playersEntry : players.entrySet()) 
        {
          Player p = playersEntry.getValue();
          if (p.age == 0)
          {
            continue;
          }
          if (dist(p.x, p.y, tc.getScreenX(width), tc.getScreenY(height - wallHeight) + wallHeight) < jumpDistanceMaxTolerance * width)
          {
              // swap previous TUIO id to new id
              println("updating tuio id of player " + p.id + " from " + p.tuioId + " to " + tc.getSessionID());
              players.remove(p.tuioId);
              players.put(tc.getSessionID(), p);
              // update player
              p.age = 0;
              p.x = tc.getScreenX(width);
              p.y = tc.getScreenY(height - wallHeight) + wallHeight;
              found = true;
              break;
          }
        }
        // add as new player if nothing found
        if (!found)
        {
          Player p = new Player(this, nextUniqueID++, tc.getSessionID(), tc.getScreenX(width), tc.getScreenY(height - wallHeight) + wallHeight);
          players.put(tc.getSessionID(), p);
          firePlayerAddEvent(p);
        }
      }
    }
    
    // update the feet
    ArrayList<TuioObject> tuioObjectList = tuioProcessing.getTuioObjectList();
    ArrayList<TuioCursor> tuioCursorList = tuioProcessing.getTuioCursorList();
    for (TuioObject to : tuioObjectList)
    {
      Player p = null;
      if (to.getSymbolID() < tuioCursorList.size())
      {
        TuioCursor tc = tuioCursorList.get(to.getSymbolID());
        p = players.get(tc.getSessionID());
      }
      if (p != null)
      {
        p.feet.add(new Foot(to.getScreenX(width), to.getScreenY(height - wallHeight) + wallHeight));
      }
      else
      {
        println("unkown foot id: " + to.getSymbolID());
      } 
    }
    
  //  println((millis() - m) + " ms update");
  }

  // ------ these callback methods are called whenever a TUIO event occurs ------------------

  // called when an object is added to the scene
  public void addTuioObject(TuioObject tobj) 
  {
    if (doDebug)
      println("add object "+tobj.getSymbolID()+" ("+tobj.getSessionID()+") "+tobj.getX()+" "+tobj.getY()+" "+tobj.getAngle());
  }

  // called when an object is removed from the scene
  public void removeTuioObject(TuioObject tobj) 
  {
    if (doDebug)
      println("remove object "+tobj.getSymbolID()+" ("+tobj.getSessionID()+")");
  }

  // called when an object is moved
  public void updateTuioObject (TuioObject tobj) 
  {
    if (doDebug)
      println("update object "+tobj.getSymbolID()+" ("+tobj.getSessionID()+") "+tobj.getX()+" "+tobj.getY()+" "+tobj.getAngle()+" "+tobj.getMotionSpeed()+" "+tobj.getRotationSpeed()+" "+tobj.getMotionAccel()+" "+tobj.getRotationAccel());
  }

  // called when a cursor is added to the scene
  public void addTuioCursor(TuioCursor tcur) 
  {
    if (doDebug)
      println("add cursor "+tcur.getCursorID()+" ("+tcur.getSessionID()+ ") "+tcur.getX()+" "+tcur.getY());
  }

  // called when a cursor is moved
  public void updateTuioCursor (TuioCursor tcur) 
  {
    if (doDebug)
      println("update cursor "+tcur.getCursorID()+" ("+tcur.getSessionID()+ ") " +tcur.getX()+" "+tcur.getY()+" "+tcur.getMotionSpeed()+" "+tcur.getMotionAccel());
  }

  // called when a cursor is removed from the scene
  public void removeTuioCursor(TuioCursor tcur) 
  {
    if (doDebug)
      println("remove cursor "+tcur.getCursorID()+" ("+tcur.getSessionID()+")");
  }

  // called after each message bundle
  // representing the end of an image frame
  public void refresh(TuioTime bundleTime) 
  { 
    redraw();
  }

  public void addTuioBlob(TuioBlob tblb)
  {
    if (doDebug)
      println("add blob "+tblb.getBlobID()+" ("+tblb.getSessionID()+ ") "+tblb.getX()+" "+tblb.getY());
  }

  public void removeTuioBlob(TuioBlob tblb)
  {
    if (doDebug)
      println("remove blob "+tblb.getBlobID()+" ("+tblb.getSessionID()+ ") "+tblb.getX()+" "+tblb.getY());
  }

  public void updateTuioBlob(TuioBlob tblb)
  {
    if (doDebug)
      println("update blob "+tblb.getBlobID()+" ("+tblb.getSessionID()+ ") "+tblb.getX()+" "+tblb.getY());
  }
}

// Version 3.1
// this class contains all the information for one player and gets updated by the PharusClient
// extend this class with your player code if needed, but do not change the functions and variables that are there already as PharusClient depends on it

class Player
{
  public Player(PharusClient pc, int id, long tuioId, float x, float y)
  {
    this.pc = pc;
    this.id = id;
    this.tuioId = tuioId;
    this.x = x;
    this.y = y;
  }

  // --- All the information about a player ---
  PharusClient pc; // do not modify this, PharusClient updates it
  int id; // do not modify this, PharusClient updates it
  long tuioId; // do not modify this, PharusClient updates it
  int age; // do not modify this, PharusClient updates it
  float x; // do not modify this, PharusClient updates it
  float y; // do not modify this, PharusClient updates it
  ArrayList<Foot> feet = new ArrayList<Foot>(); // do not modify this, PharusClient updates it

  // TODO extend this with additional fields

  float lastX = 0, lastY = 0; // hold the last check position
  float checkTime;
  
  public boolean isMoving() {
    if (lastX == 0 || lastY == 0) {
      checkTime = millis();
      lastX = this.x;
      lastY = this.y;
    }
    
    float d = PVector.dist(new PVector(lastX, lastY), new PVector(this.x, this.y));
    boolean moving =  abs(d) > 1;
    
     // update values after 300ms
    if(millis() - checkTime > 300){
      checkTime = millis();
      lastX = this.x;
      lastY = this.y;
    }
    
    return moving;
  }
  
  // --- Some functions that have information about the player ---
  public boolean isJumping()
  {
    // we assume that we jump if we have no feet and update
    return feet.size() == 0 && age > 1;
  }

  // handling of path information
  public int getNumPathPoints()
  {
    TuioCursor tc = pc.tuioProcessing.getTuioCursor(tuioId);
    if (tc != null)
    {
      return tc.getPath().size();
    }
    return -1;
  }
  public float getPathPointX(int pointID)
  {
    TuioCursor tc = pc.tuioProcessing.getTuioCursor(tuioId);
    if (tc != null)
    {
      ArrayList pointList = tc.getPath();
      if (pointList == null || pointList.size() <=  pointID)
      {
        return 0;
      }
      TuioPoint tp = (TuioPoint)pointList.get(pointID);
      return tp.getScreenX(width);
    }
    return 0;
  }
  public float getPathPointY(int pointID)
  {
    TuioCursor tc = pc.tuioProcessing.getTuioCursor(tuioId);
    if (tc != null)
    {
      ArrayList pointList = tc.getPath();
      if (pointList == null || pointList.size() <=  pointID)
      {
        return 0;
      }
      TuioPoint tp = (TuioPoint)pointList.get(pointID);
      return tc.getScreenY(height - pc.wallHeight) + pc.wallHeight;
    }
    return 0;
  }  

  // TODO extend this with additional functions
}

// helper class for feet
public class Foot
{
  public Foot(float x, float y)
  {
    this.x = x;
    this.y = y;
  }

  float x;
  float y;
}

// Version 3.1
// This example uses PharusClient class to access pharus data
// Pharus data is encapsulated into Player objects
// PharusClient provides an event callback mechanism whenever a player is been updated

PharusClient pc;

public void initPlayerTracking()
{
  pc = new PharusClient(this, dsm.wallHeight);
  // age is measured in update cycles, with 25 fps this is 2 seconds
  pc.setMaxAge(50);
  // max distance allowed when jumping between last known position and potential landing position, unit is in pixels relative to window width
  pc.setjumpDistanceMaxTolerance(0.05f);
}

public HashMap<Long, Player>  getPlayers() {
  return  pc.players;
}

public void drawPlayerTracking()
{
  // reference for hashmap: file:///C:/Program%20Files/processing-3.0/modes/java/reference/HashMap.html
  for (HashMap.Entry<Long, Player> playersEntry : pc.players.entrySet()) 
  {
    Player p = playersEntry.getValue();

    // render path of each track
    if (dsm.showPath)
    {
      if (p.getNumPathPoints() > 1)
      {
        stroke(70, 100, 150, 25.0f );        
        int numPoints = p.getNumPathPoints();
        int maxDrawnPoints = 300;
        // show the motion path of each track on the floor    
        float startX = p.getPathPointX(numPoints - 1);
        float startY = p.getPathPointY(numPoints - 1);
        for (int pointID = numPoints - 2; pointID > max(0, numPoints - maxDrawnPoints); pointID--) 
        {
          float endX = p.getPathPointX(pointID);
          float endY = p.getPathPointY(pointID);
          line(startX, startY, endX, endY);
          startX = endX;
          startY = endY;
        }
      }
    }

    // render tracks = player
    if (dsm.showTrack)
    {
      // show each track with the corresponding  id number
      noStroke();
      if (p.isJumping())
      {
        fill(192, 0, 0);
      } else
      {
        fill(192, 192, 192);
      }
      ellipse(p.x, p.y, dsm.cursor_size, dsm.cursor_size);
      fill(0);
      text(p.id /*+ "/" + p.tuioId*/, p.x, p.y);
    }

    // render feet for each track
    if (dsm.showFeet)
    {
      // show the feet of each track
      stroke(70, 100, 150, 200);
      noFill();
      // paint all the feet that we can find for one character
      for (Foot f : p.feet)
      {
        ellipse(f.x, f.y, dsm.cursor_size / 3, dsm.cursor_size / 3);
      }
    }
  }
}

public void pharusPlayerAdded(Player player)
{
  println("Player " + player.id + " added");

  // TODO do something here if needed
}

public void pharusPlayerRemoved(Player player)
{
  println("Player " + player.id + " removed");

  // TODO do something here if needed
}
class SceneEnd extends Scene {

  float amp = 100;
  
  SceneEnd(SceneManager sm) {
  }

  public void doDraw() {
    // fade music
    sm.s.volume(amp--/100);
    if (millis() - startTime > 3000) {
      exit();
    }
  }

  public void end() {
    println("FINISHED");
  }
}
class SceneHeat extends Scene {
  SceneManager sm;

  Particle[] particles;
  int particlesAmount = 10000;
  float alpha;

  int redValue = 1;
  int movingPlayers = 0;

  float heatTime = 0;

  SceneHeat(SceneManager sm) {
    println("Scene Heat created!");
    this.sm = sm;

    background(12);
    noStroke();
    setParticles();
  }

  public void doDraw() {
    this.alpha = 10;
    fill(0, alpha);
    rect(0, 0, dsm.windowWidth, dsm.windowHeight);

    // if 50% of all players move, increase heat
    int movingLimit = (int)pc.players.size() / 2;
    if (this.movingPlayers > movingLimit && this.redValue < 255) {     
      this.redValue++;
      if (this.heatTime == 0 && this.redValue == 255) {
        this.heatTime = millis();
      }
    } else {
      if (this.redValue > 10 ) {
        this.redValue -= 10;
      }
    }

    loadPixels();

    for (Particle p : this.particles) {
      p.move();
    }
    updatePixels();
    updateAvgPlayers();
    // start end fade after heat was on for 20000ms
    if (millis() - startTime > 20000) {
      this.startEnd();
    }
  }

  public void end() {
    println("ended SceneHeat");
    this.sm.setScene(new SceneMigration(this.sm));
  }

  public void setParticles() {
    particles = new Particle[particlesAmount];
    for (int i = 0; i < particlesAmount; i++) { 
      float x = random(width);
      float y = random(height);
      float adj = map(y, 0, height, 255, 0);
      int c = color(40, adj, 255);
      this.particles[i] = new Particle(x, y, c);
    }
  }

  public void updateAvgPlayers() {
    this.movingPlayers = 0;
    for (HashMap.Entry<Long, Player> playersEntry : pc.players.entrySet()) 
    {
      Player p = playersEntry.getValue();
      if (p.isMoving()) {
        this.movingPlayers++;
      }
    }
  }

  class Particle {
    float posX, posY, incr, theta;
    int c;

    Particle(float x, float y, int c) {
      this.posX = x;
      this.posY = y;
      this.c = c;
    }

    public void move() {
      update();
      wrap();
      display();
    }

    public void update() {
      incr +=  0.008f;
      theta = noise(posX * 0.006f, posY * 0.004f, incr) * TWO_PI;
      posX += 2 * cos(theta);
      posY += 2 * sin(theta);
    }

    public void updateColor() {
      this.c = color(redValue, green(this.c), 255 - redValue);
    }

    public void display() {
      updateColor();
      if (posX > 0 && posX < width && posY > 0  && posY < height) {
        pixels[(int)posX + (int)posY * width] =  c;
      }
    }

    public void wrap() {
      if (posX < 0) posX = width;
      if (posX > width ) posX =  0;
      if (posY < 0 ) posY = height;
      if (posY > height) posY =  0;
    }
  }
}
class SceneIntro extends Scene {

  SceneManager sm;
  PFont font;
  int fontSize = 32;

  String[] sentences = {
    "", 
    "", 
    "The climate crisis is the battle of our time", 
    "We are facing the biggest environmental", 
    "challenge our species has ever seen.", 
    "Your choices will have a lasting", 
    "impact on our planet"
  };

  int duration, sentence = 0;
  int alphaLerp = 0, alphaDirection = 4;

  SceneIntro(SceneManager sm) {
    println("SceneIntro started");

    this.sm = sm;
    this.fontSize = 120 / dsm.shrink;

    font = createFont("Kanit-Light.ttf", fontSize);
    textFont(font, fontSize);
    textAlign(CENTER, CENTER);
  }

  public void doDraw() {
    background(12);
    //rect(0, 0, dsm.windowWidth, dsm.windowHeight);
    alphaLerp += alphaDirection;


    noStroke();
    fill(255, 255, 255, alphaLerp);
    text(sentences[sentence], dsm.windowWidth/2, dsm.wallHeight / 2);

    if (alphaLerp >= 255 || alphaLerp <= 0) {
      alphaDirection *= -1;
    } 

    if (alphaLerp <=0) {
      sentence++;
      if (sentence == sentences.length) {
        this.end();
      }
    }
  }

  public void end() {
    println("ended SceneIntro");
    this.sm.setScene(new SceneWind(this.sm));
  }
}


abstract class Scene {

  int startTime = millis();
  int endTime = 0;
  int fadingTime = 3000; // how long the fade should take

  public abstract void doDraw();
  public void end() {
  };

  public void startEnd() {

    // if we trigger this the first time, store current time
    if (!this.ended()) {
      this.endTime = millis();
    }

    // as long as fading time is not over, fill the whole screen with a transparent color
    if (millis() - this.endTime < this.fadingTime) {
      fill(12, 12, 12, 12);
      rect(0, 0, dsm.windowWidth, dsm.windowHeight);
    } else {
      // switch to next scene, if we are done fading
      this.end();
    }
  };

  // returns true if scene has already ended
  public boolean ended() {
    return this.endTime != 0;
  }

  public void handleMouseClicked() {
  };
  public void handleMouseDragged() {
  };
  public void handleMousePressed() {
  };
  public void handleMouseReleased() {
  };
  public void handleKeyPressed() {
  };
}


class SceneManager {

  Scene scene;
  SoundFile file;
  Sound s;

  SceneManager(PApplet p) {
    this.scene = new SceneIntro(this);
    this.s = new Sound(p);

 
  }

  public void setScene(Scene scene) {
    this.scene = scene;
  }

  public void doDraw() {
    if (!this.scene.ended()) {
      this.scene.doDraw();
    } else {
      // if scene ended, continue fading
      this.scene.startEnd();
    }
  }

  public void handleMouseClicked() {
    this.scene.handleMouseClicked();
  }

  public void handleMouseDragged() {
    this.scene.handleMouseDragged();
  }

  public void handleMousePressed() {
    this.scene.handleMousePressed();
  }

  public void handleMouseReleased() {
    this.scene.handleMouseReleased();
  }

  public void handleKeyPressed() {
    this.scene.handleKeyPressed();
  }
}

class SceneMigration extends Scene {

  SceneManager sm;

  int padding;

  ArrayList <Mover> m;

  int xRes = 50;
  int yRes = 28;
  float posX;
  float posY;

  int redValue = 1;
  int movingPlayers = 0;
  
  int c = 150;

  boolean bDisplayVectorField = false, displayParticle = true;

  SceneMigration(SceneManager sm) {  
    println("Scene Migration created!");
    this.sm = sm;

    padding = -2;
    posX = width/2+1;
    posY = 0;
    m = new ArrayList();

    background (0xff111111);

    for (int i = 0; i < 2000; i++)
    {
      m.add (new Mover());
    }
  }

  public void doDraw() {
    randomSeed (0);

    //blur(1);
    // fastblur (1);

    noStroke();
    fill (7, 15);
    rect (0, 0, width, height);
    
    // if 33% of all players move, add ranodm noise
    int movingLimit = (int)pc.players.size() / 3;
    if (this.movingPlayers > movingLimit) {     
      noiseSeed ((int) random (10000));
      this.c = 100;
    } else {
      this.c = 200;
    }

    posX = lerp (posX, (mousePressed ? mouseX : noise (frameCount /500.0f) * width /*noise (20+frameCount / 100.0)*1.5*/), 0.05f);
    posY = lerp (posY, mousePressed ? map (mouseY, 0, height, 0, 1) : (noise (100+frameCount / 400.0f)), 0.05f) ;


    if (displayParticle)
    {
      for (int i = 0; i < m.size(); i++)
      {
        m.get(i).move();
        m.get (i).setVelo (posX, posY, noise (frameCount / 300.0f));
        m.get(i).checkEdges();  

        m.get(i).display(144);
      }
    }
    //copy (1, 1, width, height, -1, -1, width+3, height+3);


    if (bDisplayVectorField) displayVectorField();
    updateAvgPlayers();

    // our random end declaration
    // start end fade after 15 seconds
    if (millis() - startTime > 15000) {
      this.startEnd();
    }
  }

  public void handleKeyPressed() {
    if (key == 'b') bDisplayVectorField = !bDisplayVectorField;
    if (key == 'p') displayParticle = !displayParticle;
    if (key == '+') m.add (new Mover());

    if (key == ' ') noiseSeed ((int) random (10000));

    if (key == '-')
    {
      if (m.size() > 0) m.remove (0);
    }
  }

  public void updateAvgPlayers() {
    this.movingPlayers = 0;
    for (HashMap.Entry<Long, Player> playersEntry : pc.players.entrySet()) 
    {
      Player p = playersEntry.getValue();
      if (p.isMoving()) {
        this.movingPlayers++;
      }
    }
  }

  public void end() {
    println("ended SceneMigration");
    this.sm.setScene(new SceneParticleGlobe(this.sm));
  }

  class Mover 
  {
    PVector location;
    PVector velo;
    float speed;

    Mover ()
    {
      location = new PVector(random(width), random(height));
      velo = new PVector(random(-1, 1), random(-1, 1));
      velo.normalize();

      speed = random (1, 3);
    }

    public void setVelo (float posX, float posY, float stength)
    {

      float angle, fAngle;

      float dis;
      float mm = map (posX, 0, width, -1.2f, 1.2f);
      if (mm == 0) mm = 0.0001f;
      float maxDis = mm*dist (0, 0, width/2, height/2);


      dis = dist (location.x, location.y, width/2, height/2);
      fAngle = map (dis, 0, maxDis, posY, 0);
      angle = map (dis, 0, maxDis, PI, 0) +  random (-PI/4*fAngle, PI/4*fAngle);

      velo.x += cos (angle)*stength;
      velo.y += sin (angle)*stength;

      velo.normalize();
    }


    public void move ()
    {

      location.add (multi (velo, speed));
    }

    public void checkEdges ()
    {
      if (location.x < 0 || location.x > width || location.y < 0 || location.y > height)
      {
        location.x = random (width);
        location.y = random (height);
      }
    }

    public PVector multi (PVector v, float m)
    {
      return new PVector (v.x*m, v.y*m);
    }


    public void display (int c)
    {
      //strokeWeight (0.5);
      fill(0xffb1c999, 255);
      stroke(c);
      point (location.x, location.y);
    }
  }

  public void displayVectorField()
  {
    stroke (0xffb1c999, 40);
    stroke (247, 20);

    float xSpan = (width - (xRes-1)*(float) padding) / xRes;
    float ySpan = (height - (yRes-1)*(float) padding) / yRes;

    float x, y, angle;
    noFill();

    float dis;
    float mm = map (posX, 0, width, -1.5f, 1.5f);
    if (mm == 0) mm = 0.0001f;
    float maxDis = mm*dist (0, 0, width/2, height/2);
    float fAngle;

    for (int i = 0; i < yRes; i++)
    {
      for (int j = 0; j < xRes; j++)
      {

        x = xSpan * j + padding*j + xSpan/2;
        y = ySpan * i + padding*i + ySpan/2;
        dis = dist (x, y, width/2, height/2);
        fAngle = map (dis, 0, maxDis, posY, 0);
        angle = map (dis, 0, maxDis, PI, 0) +  random (-PI/4*fAngle, PI/4*fAngle);

        line (x, y, x+cos (angle) * xSpan, y + sin (angle) * ySpan);
      }
    }
  }
}
class SceneParticleGlobe extends Scene { //<>// //<>// //<>// //<>//
  SceneManager sm;

  int time;
  int playerDelay;
  int globeRadius;

  ArrayList<PVector> position = new ArrayList<PVector>();
  ArrayList<PVector> velocity = new ArrayList<PVector>();

  ArrayList<Float> mass = new ArrayList<Float>();
  ArrayList<Integer> colors = new ArrayList<Integer>();
  ArrayList<String> types = new ArrayList<String>();
  ArrayList<Integer> polygons = new ArrayList<Integer>();

  SceneParticleGlobe(SceneManager SM) {
    sm = SM;
    time = millis();
    playerDelay = millis();
    globeRadius = (int) (dsm.windowHeight/2.5f);


    /*mass.add(mass.size(), 30.0);
     position.add(position.size(), new PVector(dsm.windowWidth/2, dsm.windowHeight/2));
     velocity.add(velocity.size(), new PVector(0, 0));
     colors.add(mass.size(), 0);*/
  }

  public void end() {
    this.sm.setScene(new SceneEnd(this.sm));
  }

  public void doDraw() {
    noStroke();
    background(15);
    //translate(100,0);

    if (millis() > time) {
      time += (int) random(25, 100);
      addRandomParticle();
      randomizePolygons();
    }

    if (millis() > playerDelay) {
      playerDelay += (int) random(400, 1000);
      checkPlayerLocation();
    }

    for (int particle = 0; particle < mass.size(); particle++) {
      position.get(particle).lerp(new PVector(dsm.windowWidth+dsm.windowWidth/2.17f, dsm.windowHeight/2-500), 0.001f);
    }

    //rotate the globe

    for (int particle = 0; particle < mass.size(); particle++) {
      position.get(particle).rotate(radians(.1f));
    }
    //translate(dsm.windowWidth/2, dsm.windowHeight/2);

    for (int particleA = 0; particleA < mass.size(); particleA++) {
      float accelerationX = 0, accelerationY = 0;

      for (int particleB = 0; particleB < mass.size(); particleB++) {
        if (particleA != particleB) {
          //float distanceX = positionX.get(particleB) - positionX.get(particleA);
          //float distanceY = positionY.get(particleB) - positionY.get(particleA);

          float distance;
          float distanceX = position.get(particleB).x - position.get(particleA).x;
          float distanceY = position.get(particleB).y - position.get(particleA).y;

          distance = sqrt(distanceX * distanceX + distanceY * distanceY);
          if (distance < 1) distance = 1;

          float force = (distance - globeRadius) * mass.get(particleB) / distance;
          accelerationX += force * distanceX;
          accelerationY += force * distanceY;
        }
      }

      velocity.set(particleA, new PVector(velocity.get(particleA).x * 0.75f + accelerationX * mass.get(particleA), velocity.get(particleA).y * 0.50f + accelerationY * mass.get(particleA)));
      velocity.get(particleA).rotate(radians(10));
    }

    int n = 0;
    //push();
    for (int particle = 0; particle < mass.size(); particle++) {
      //positionX.set(particle, positionX.get(particle) + velocityX.get(particle));
      //positionY.set(particle, positionY.get(particle) + velocityY.get(particle));
      float w = mass.get(particle) * 1000;
      float x = position.get(particle).x;
      float y = position.get(particle).y;

      position.set(particle, new PVector(position.get(particle).x + velocity.get(particle).x, position.get(particle).y + velocity.get(particle).y));
      fill(colors.get(particle));
      x = position.get(particle).x;
      y = position.get(particle).y;

      if (types.get(particle) == "circle") {
        ellipse(x, y, w, w);
      } else if (types.get(particle) == "polygon") {
        polygon(x, y, w/2, polygons.get(n));
        n++;
      } else if (types.get(particle) == "square") {
        polygon(x, y, w/2, 4);
      }
    }
    //pop();

    // start end fade after 30s
    if (millis() - startTime > 60000) {
      this.startEnd();
    }
  }

  public void addRandomParticle() {
    if (random(0, 1) < 0.4f) {
      colors.add(color(15, 200, 12, 144));
    } else {
      colors.add(color(0, 25, 200, 144));
    }
    mass.add(random(0.003f, 0.03f));
    //positionX.add((float)random(10, dsm.windowWidth-10));
    //positionY.add((float)random(10, dsm.windowHeight/2));

    position.add(new PVector((float)random(10, dsm.windowWidth-10), (float)random(10, dsm.windowHeight/2)));

    //velocityX.add(0.0);
    //velocityY.add(0.0);

    velocity.add(new PVector(0.0f, 0.0f));
    types.add("circle");
  }

  public void randomizePolygons() {
    for (int i = 0; i<polygons.size(); i++) {
      polygons.set(i, (int)random(4, 8));
    }
  }

  public void addNewParticle(int x, int y) {
    if (y > dsm.windowHeight / 2) {
      if (x <= dsm.windowWidth / 2) {
        colors.add(color(110, 110, 110, 87));
        types.add("square");
      } else {
        colors.add(color(164, 34, 18, 114));
        types.add("polygon");
        polygons.add((int)random(4, 8));
      }

      mass.add(random(0.003f, 0.03f));
      //positionX.add((float)x);
      //positionY.add((float)y);

      position.add(new PVector((float)x, (float)y));

      //velocityX.add(0.0);
      //velocityY.add(0.0);

      velocity.add(new PVector(0.0f, 0.0f));
    }
  }

  public void polygon(float x, float y, float radius, int npoints) {
    float angle = TWO_PI / npoints;
    beginShape();
    for (float a = 0; a < TWO_PI; a += angle) {
      float sx = x + cos(a) * radius;
      float sy = y + sin(a) * radius;
      vertex(sx, sy);
    }
    endShape(CLOSE);
  }

  public void checkPlayerLocation() {
    for (HashMap.Entry<Long, Player> playersEntry : pc.players.entrySet()) 
    {
      Player p = playersEntry.getValue();
      println(p.x, p.y);
      this.addNewParticle((int)p.x, (int)p.y);
    }
  }

  public void handleMouseClicked() {
    addNewParticle(mouseX, mouseY);
  }

  public void handleMouseDragged() {
    //addNewParticle();
  }
}
class SceneSeaLevelRise extends Scene {

  SceneManager sm;

  float yoff = 0.0f;   
  float g = 240;
  float b = 240;
  float transY = 0;
  boolean bgCleared = false;

  SceneSeaLevelRise(SceneManager sm) {
    println("SceneSeaLevelRise started");
    this.sm = sm;
  }

  public void doDraw() {
    //blue-bluegreen-green  
    g += random(-150, 10);
    b += random(-100, 10);
    //restrictions
    if (g < 210 || b < 220 || g > 255 || b > 255)
    {
      g = random(100, 255);
      b = random(220, 255);
    }

    //fill(255);
    beginShape();

    float xoff = 0;
    for (float x = 0; x <= dsm.windowWidth; x += 10) {
      float y = map(noise(xoff, yoff), 0, 1, 200, dsm.wallHeight); 
      vertex(x, y); 
      xoff += 0.04f; // modify for steeper waves
      stroke(72, g, b);
      strokeWeight(1);
      fill(0, 20, 46);
    }

    yoff += 0.01f; // smooths the wave speed
    vertex(dsm.windowWidth, height-600);
    vertex(0, transY);
    transY += 1000;
    endShape(CLOSE);

    // start end fade after 10000ms
    if (millis() - startTime > 13000) {
      this.startEnd();
    }

    if (!bgCleared) {
      bgCleared = true;
      fill(12, 12, 12);
      rect(0, 0, dsm.windowWidth, dsm.windowHeight);
    }
  }

  public void end() {
    println("ended SceneSeaLevelRise");
    this.sm.setScene(new SceneHeat(this.sm));
  }
}

class SceneWind extends Scene {
  SceneManager sm;

  int noiseScale = 1500, noiseStrength = 3, amount = 10000;

  Particle[] particles = new Particle[amount];
  Repeller r = new Repeller(dsm.windowWidth / 2, dsm.wallHeight /2);
  HashMap<Long, Repeller> repellers = new HashMap<Long, Repeller>();

  int[] windColors = {color(50, 50, 150), color(100, 200, 250), color(255, 255, 255)};

  SceneWind(SceneManager sm) {  
    println("Scene Wind created!");
    this.sm = sm;

    for (int i = 0; i < amount; i++) {
      float alpha = map(i, 0, amount, 0, 250);
      int colorIndex = i % 3;
      int tempColor = color(red(windColors[colorIndex]), green(windColors[colorIndex]), blue(windColors[colorIndex]), alpha);
      particles[i] = new Particle(i, random(10, dsm.windowWidth), random(10, dsm.wallHeight), tempColor);
    }
  }

  public void addRepellers() {
    //repellers.clear();
    for (HashMap.Entry<Long, Player> playersEntry : pc.players.entrySet()) 
    {
      Player p = playersEntry.getValue();
      fill(0);
      ellipse(p.x, p.y, 122, 122);
      repellers.put(p.tuioId, new Repeller(p.x, p.y - dsm.floorHeight));
    }
  }

  public void drawRepellers() {
    for (HashMap.Entry<Long, Repeller> repeller : repellers.entrySet()) 
    {
      repeller.getValue().display();
    }
  }

  public void doDraw() {

    noStroke();
    smooth();

    fill(12, 12, 12, 10);

    rect(0, 0, dsm.windowWidth, dsm.windowHeight);
    addRepellers();
    //drawRepellers();

    // background(21, 8, 50);
    for (int i = 0; i < particles.length; i++) {

      // calculate strongest force of all repellers
      PVector strongestForce = new PVector(0, 0);
      for (Map.Entry rep : repellers.entrySet()) { 
        Repeller r = (Repeller)rep.getValue(); 

        PVector repellForce = r.repel(particles[i]);
        if (strongestForce.mag() <repellForce.mag()) {
          strongestForce = repellForce.copy();
        }
      } 

      PVector pos = particles[i].pos;
      // apply perlin force
      float angle = noise(pos.x / noiseScale, pos.y / noiseScale) * TWO_PI * noiseStrength;
      PVector dir = new PVector(cos(angle), sin(angle));
      particles[i].applyForce(dir.add(strongestForce));
      particles[i].step();
    }

    // start end fade after 17000ms
    if (millis() - startTime > 20000) {
      this.startEnd();
    }
  }

  public void handleMouseDragged() {
    r.location = new PVector(mouseX, mouseY);
  }

  public void handleMousePressed() {
    repellers.put((long)1, new Repeller(mouseX, mouseY));
  }

  public void end() {
    println("ended SceneWind");
    this.sm.setScene(new SceneSeaLevelRise(this.sm));
  }

  class Particle {

    PVector acc, vel, dir, pos, prev;
    LinkedList<PVector>trail = new LinkedList<PVector>(); 

    float speed = random(0.4f, 0.9f);
    float mass = 1;

    int id;
    int fillColor;

    Particle(int id, float x, float y, int c) {
      this.id = id;
      this.fillColor = c;
      this.pos = new PVector(x, y);
      this.prev = new PVector(x, y);
      this.vel = new PVector(0, 0);
      this.dir = new PVector(0, 0);
      this.acc = new PVector(0, 0);
    }

    public void step() {
      update();
      display();
      checkEdge();
    }

    public void update() {

      vel.add(acc);
      pos.add(vel.limit(0.8f));
      acc.mult(0);
    }

    public void applyForce(PVector force) {
      force.div(mass);
      acc.add(force);
    }

    public void checkEdge() {
      if (this.outOfBoundaries()) {
        this.pos.x = random(1, dsm.windowWidth);
        this.pos.y = random(1, dsm.wallHeight);
        this.checkEdge();
      }
    }

    public boolean outOfBoundaries() {
      return this.pos.x > dsm.windowWidth || this.pos.x < 0 || this.pos.y > dsm.wallHeight || this.pos.y < 0;
    }

    public void display() {
      fill(this.fillColor);
      ellipse(this.pos.x, this.pos.y, 3, 3);
      // mirror to bottom
      ellipse(this.pos.x, this.pos.y + dsm.wallHeight, 3, 3);
    }
  }


  class Repeller {
    PVector location;
    float r = 122;
    float strength = 2000;

    boolean drawn = false;

    Repeller(float x, float y) {
      location = new PVector(x, y);
    }

    public PVector repel(Particle p) {
      PVector dir = PVector.sub(location, p.pos);
      float d = dir.mag();
      dir.normalize();
      d = constrain(d, 5, 200);

      float force = -strength / (d * d);
      dir.mult(force);
      return dir;
    }

    public void display() {
      fill(255);
      ellipse(location.x, location.y, r, r);
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "generativeArts" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
